package main

import (
	"client/menu"
)

func main() {
	menu.RemoteMenu()
	// conn.EndConnection(conn.Cnn)
}
