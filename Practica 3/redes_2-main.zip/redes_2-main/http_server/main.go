package main

import (
	"http_server/http"
)

func main() {
	http.StartSever()
}
