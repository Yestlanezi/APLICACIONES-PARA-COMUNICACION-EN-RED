package main

import (
	c "udp_go/client/game_client"
)

func main() {
	c.Client()
}
